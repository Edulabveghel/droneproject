﻿namespace Ground_station_GUI
{
    partial class GroundstationGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GroundstationGUI));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar2 = new System.Windows.Forms.ToolStripProgressBar();
            this.dronePositionUpdate = new System.Windows.Forms.Timer(this.components);
            this.TabMenuStructure = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ModeSelectionPanel = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.mapViewPanel = new System.Windows.Forms.Panel();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.tableViewPanel = new System.Windows.Forms.Panel();
            this.tblNavigationPoints = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.If_safety_Xmax = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.If_safety_Zmax = new System.Windows.Forms.NumericUpDown();
            this.If_safety_Zmin = new System.Windows.Forms.NumericUpDown();
            this.If_safety_Ymax = new System.Windows.Forms.NumericUpDown();
            this.If_safety_Ymin = new System.Windows.Forms.NumericUpDown();
            this.If_safety_Xmin = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.btnSubmitSafetyBox = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.btnSubmitDroneInitialPosition = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.If_drone_intial_Zposition = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.If_drone_intial_Yposition = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.If_drone_intial_Xposition = new System.Windows.Forms.NumericUpDown();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.btnSubmitAdjustRoom = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.If_room_height = new System.Windows.Forms.NumericUpDown();
            this.If_room_width = new System.Windows.Forms.NumericUpDown();
            this.If_room_lenght = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.btnCallWebservicePosition = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnHold = new System.Windows.Forms.Button();
            this.btnAbort = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnExecute = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.HeaderPanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnClearMeasurment = new System.Windows.Forms.Button();
            this.btnEditMeasurment = new System.Windows.Forms.Button();
            this.btnAddMeasurment = new System.Windows.Forms.Button();
            this.btnClearFlightTable = new System.Windows.Forms.Button();
            this.btnGenerateFlightTable = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.If_Xposition = new System.Windows.Forms.NumericUpDown();
            this.If_Yposition = new System.Windows.Forms.NumericUpDown();
            this.If_Zposition = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.ControlPanel = new System.Windows.Forms.Panel();
            this.btnReset = new System.Windows.Forms.Button();
            this.BottomPanel = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Indication_timer = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1.SuspendLayout();
            this.TabMenuStructure.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.ModeSelectionPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.mapViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tableViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblNavigationPoints)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Xmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Zmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Zmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Ymax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Ymin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Xmin)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.If_drone_intial_Zposition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_drone_intial_Yposition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_drone_intial_Xposition)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.If_room_height)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_room_width)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_room_lenght)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.HeaderPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.If_Xposition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_Yposition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_Zposition)).BeginInit();
            this.ControlPanel.SuspendLayout();
            this.BottomPanel.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripProgressBar2});
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            // 
            // toolStripStatusLabel1
            // 
            resources.ApplyResources(this.toolStripStatusLabel1, "toolStripStatusLabel1");
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            // 
            // toolStripProgressBar2
            // 
            this.toolStripProgressBar2.Margin = new System.Windows.Forms.Padding(500, 0, 0, 0);
            this.toolStripProgressBar2.Name = "toolStripProgressBar2";
            this.toolStripProgressBar2.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            resources.ApplyResources(this.toolStripProgressBar2, "toolStripProgressBar2");
            // 
            // dronePositionUpdate
            // 
            this.dronePositionUpdate.Enabled = true;
            this.dronePositionUpdate.Interval = 5000;
            this.dronePositionUpdate.Tick += new System.EventHandler(this.dronePositionUpdate_Tick);
            // 
            // TabMenuStructure
            // 
            resources.ApplyResources(this.TabMenuStructure, "TabMenuStructure");
            this.TabMenuStructure.Controls.Add(this.tabPage1);
            this.TabMenuStructure.Controls.Add(this.tabPage2);
            this.TabMenuStructure.Controls.Add(this.tabPage3);
            this.TabMenuStructure.Controls.Add(this.tabPage4);
            this.TabMenuStructure.HotTrack = true;
            this.TabMenuStructure.Name = "TabMenuStructure";
            this.TabMenuStructure.SelectedIndex = 0;
            this.TabMenuStructure.SelectedIndexChanged += new System.EventHandler(this.TabMenuStructure_TabIndexChanged);
            this.TabMenuStructure.TabIndexChanged += new System.EventHandler(this.TabMenuStructure_TabIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chart1);
            this.tabPage1.Controls.Add(this.ModeSelectionPanel);
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            resources.ApplyResources(this.chart1, "chart1");
            this.chart1.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea1.Area3DStyle.Inclination = 20;
            chartArea1.Area3DStyle.LightStyle = System.Windows.Forms.DataVisualization.Charting.LightStyle.Realistic;
            chartArea1.Area3DStyle.Rotation = 20;
            chartArea1.Area3DStyle.WallWidth = 0;
            chartArea1.AxisX.Interval = 1D;
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            chartArea1.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea1.AxisY.Interval = 1D;
            chartArea1.AxisY.IntervalOffsetType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea1.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea1.BackImage = "P:\\BU9\\01 Operationeel\\06 Stage-afstudeer\\Studenten\\Algemeen\\201608-201701 Rob va" +
    "n Steene\\8. Overige\\Edulab plattegrond GUI.png";
            chartArea1.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.BottomLeft;
            chartArea1.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Scaled;
            chartArea1.BorderColor = System.Drawing.Color.Maroon;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Cursor = System.Windows.Forms.Cursors.Cross;
            legend1.Name = "Legend:";
            this.chart1.Legends.Add(legend1);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
            series1.IsVisibleInLegend = false;
            series1.Legend = "Legend:";
            series1.Name = "Series1";
            series1.YValuesPerPoint = 2;
            this.chart1.Series.Add(series1);
            this.chart1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseMove);
            // 
            // ModeSelectionPanel
            // 
            this.ModeSelectionPanel.Controls.Add(this.groupBox1);
            resources.ApplyResources(this.ModeSelectionPanel, "ModeSelectionPanel");
            this.ModeSelectionPanel.Name = "ModeSelectionPanel";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton6);
            this.groupBox1.Controls.Add(this.radioButton5);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // radioButton6
            // 
            resources.ApplyResources(this.radioButton6, "radioButton6");
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            resources.ApplyResources(this.radioButton5, "radioButton5");
            this.radioButton5.Checked = true;
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.TabStop = true;
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.mapViewPanel);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.tableViewPanel);
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // mapViewPanel
            // 
            this.mapViewPanel.Controls.Add(this.chart2);
            resources.ApplyResources(this.mapViewPanel, "mapViewPanel");
            this.mapViewPanel.Name = "mapViewPanel";
            // 
            // chart2
            // 
            resources.ApplyResources(this.chart2, "chart2");
            this.chart2.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea2.Area3DStyle.Inclination = 20;
            chartArea2.Area3DStyle.LightStyle = System.Windows.Forms.DataVisualization.Charting.LightStyle.Realistic;
            chartArea2.Area3DStyle.Rotation = 20;
            chartArea2.Area3DStyle.WallWidth = 0;
            chartArea2.AxisX.Interval = 1D;
            chartArea2.AxisX.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            chartArea2.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea2.AxisY.Interval = 1D;
            chartArea2.AxisY.IntervalOffsetType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea2.AxisY.MajorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea2.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea2.BackImage = "P:\\BU9\\01 Operationeel\\06 Stage-afstudeer\\Studenten\\Algemeen\\201608-201701 Rob va" +
    "n Steene\\8. Overige\\Edulab plattegrond GUI.png";
            chartArea2.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.BottomLeft;
            chartArea2.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Scaled;
            chartArea2.BorderColor = System.Drawing.Color.Maroon;
            chartArea2.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea2);
            this.chart2.Cursor = System.Windows.Forms.Cursors.Cross;
            legend2.Name = "Legend:";
            this.chart2.Legends.Add(legend2);
            this.chart2.Name = "chart2";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastPoint;
            series2.IsVisibleInLegend = false;
            series2.Legend = "Legend:";
            series2.Name = "Series1";
            series2.YValuesPerPoint = 2;
            this.chart2.Series.Add(series2);
            this.chart2.PostPaint += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.ChartPaintEventArgs>(this.chart2_PostPaint);
            this.chart2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.chart2_MouseClick);
            this.chart2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseMove);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton3);
            this.groupBox3.Controls.Add(this.radioButton4);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.ForeColor = System.Drawing.Color.Black;
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // radioButton3
            // 
            resources.ApplyResources(this.radioButton3, "radioButton3");
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            resources.ApplyResources(this.radioButton4, "radioButton4");
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // tableViewPanel
            // 
            this.tableViewPanel.Controls.Add(this.tblNavigationPoints);
            resources.ApplyResources(this.tableViewPanel, "tableViewPanel");
            this.tableViewPanel.Name = "tableViewPanel";
            // 
            // tblNavigationPoints
            // 
            resources.ApplyResources(this.tblNavigationPoints, "tblNavigationPoints");
            this.tblNavigationPoints.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblNavigationPoints.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tblNavigationPoints.Name = "tblNavigationPoints";
            this.tblNavigationPoints.ReadOnly = true;
            this.tblNavigationPoints.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tblNavigationPoints_SelectionChanged);
            this.tblNavigationPoints.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.tblNavigationPoints_RowPostPaint);
            this.tblNavigationPoints.SelectionChanged += new System.EventHandler(this.tblNavigationPoints_SelectionChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel4);
            this.tabPage3.Controls.Add(this.panel8);
            this.tabPage3.Controls.Add(this.panel7);
            resources.ApplyResources(this.tabPage3, "tabPage3");
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.If_safety_Xmax);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.If_safety_Zmax);
            this.panel4.Controls.Add(this.If_safety_Zmin);
            this.panel4.Controls.Add(this.If_safety_Ymax);
            this.panel4.Controls.Add(this.If_safety_Ymin);
            this.panel4.Controls.Add(this.If_safety_Xmin);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.btnSubmitSafetyBox);
            this.panel4.Controls.Add(this.label31);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.label15);
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // If_safety_Xmax
            // 
            this.If_safety_Xmax.DecimalPlaces = 1;
            this.If_safety_Xmax.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_safety_Xmax, "If_safety_Xmax");
            this.If_safety_Xmax.Name = "If_safety_Xmax";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // If_safety_Zmax
            // 
            this.If_safety_Zmax.DecimalPlaces = 1;
            this.If_safety_Zmax.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_safety_Zmax, "If_safety_Zmax");
            this.If_safety_Zmax.Name = "If_safety_Zmax";
            // 
            // If_safety_Zmin
            // 
            this.If_safety_Zmin.DecimalPlaces = 1;
            this.If_safety_Zmin.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_safety_Zmin, "If_safety_Zmin");
            this.If_safety_Zmin.Name = "If_safety_Zmin";
            // 
            // If_safety_Ymax
            // 
            this.If_safety_Ymax.DecimalPlaces = 1;
            this.If_safety_Ymax.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_safety_Ymax, "If_safety_Ymax");
            this.If_safety_Ymax.Name = "If_safety_Ymax";
            // 
            // If_safety_Ymin
            // 
            this.If_safety_Ymin.DecimalPlaces = 1;
            this.If_safety_Ymin.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_safety_Ymin, "If_safety_Ymin");
            this.If_safety_Ymin.Name = "If_safety_Ymin";
            // 
            // If_safety_Xmin
            // 
            this.If_safety_Xmin.DecimalPlaces = 1;
            this.If_safety_Xmin.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_safety_Xmin, "If_safety_Xmin");
            this.If_safety_Xmin.Name = "If_safety_Xmin";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // btnSubmitSafetyBox
            // 
            resources.ApplyResources(this.btnSubmitSafetyBox, "btnSubmitSafetyBox");
            this.btnSubmitSafetyBox.Name = "btnSubmitSafetyBox";
            this.btnSubmitSafetyBox.UseVisualStyleBackColor = true;
            this.btnSubmitSafetyBox.Click += new System.EventHandler(this.btnSubmitSafetyBox_Click);
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.Name = "label31";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label24);
            this.panel8.Controls.Add(this.btnSubmitDroneInitialPosition);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.If_drone_intial_Zposition);
            this.panel8.Controls.Add(this.label26);
            this.panel8.Controls.Add(this.If_drone_intial_Yposition);
            this.panel8.Controls.Add(this.label27);
            this.panel8.Controls.Add(this.If_drone_intial_Xposition);
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.Name = "panel8";
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            // 
            // btnSubmitDroneInitialPosition
            // 
            resources.ApplyResources(this.btnSubmitDroneInitialPosition, "btnSubmitDroneInitialPosition");
            this.btnSubmitDroneInitialPosition.Name = "btnSubmitDroneInitialPosition";
            this.btnSubmitDroneInitialPosition.UseVisualStyleBackColor = true;
            this.btnSubmitDroneInitialPosition.Click += new System.EventHandler(this.btnSubmitDroneInitialPosition_Click);
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            // 
            // If_drone_intial_Zposition
            // 
            this.If_drone_intial_Zposition.DecimalPlaces = 1;
            this.If_drone_intial_Zposition.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_drone_intial_Zposition, "If_drone_intial_Zposition");
            this.If_drone_intial_Zposition.Name = "If_drone_intial_Zposition";
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            // 
            // If_drone_intial_Yposition
            // 
            this.If_drone_intial_Yposition.DecimalPlaces = 1;
            this.If_drone_intial_Yposition.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_drone_intial_Yposition, "If_drone_intial_Yposition");
            this.If_drone_intial_Yposition.Name = "If_drone_intial_Yposition";
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.Name = "label27";
            // 
            // If_drone_intial_Xposition
            // 
            this.If_drone_intial_Xposition.DecimalPlaces = 1;
            this.If_drone_intial_Xposition.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_drone_intial_Xposition, "If_drone_intial_Xposition");
            this.If_drone_intial_Xposition.Name = "If_drone_intial_Xposition";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label23);
            this.panel7.Controls.Add(this.btnSubmitAdjustRoom);
            this.panel7.Controls.Add(this.label19);
            this.panel7.Controls.Add(this.If_room_height);
            this.panel7.Controls.Add(this.If_room_width);
            this.panel7.Controls.Add(this.If_room_lenght);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.label17);
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            // 
            // btnSubmitAdjustRoom
            // 
            resources.ApplyResources(this.btnSubmitAdjustRoom, "btnSubmitAdjustRoom");
            this.btnSubmitAdjustRoom.Name = "btnSubmitAdjustRoom";
            this.btnSubmitAdjustRoom.UseVisualStyleBackColor = true;
            this.btnSubmitAdjustRoom.Click += new System.EventHandler(this.btnAdjustRoom_Click);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // If_room_height
            // 
            this.If_room_height.DecimalPlaces = 1;
            this.If_room_height.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_room_height, "If_room_height");
            this.If_room_height.Name = "If_room_height";
            // 
            // If_room_width
            // 
            this.If_room_width.DecimalPlaces = 1;
            this.If_room_width.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_room_width, "If_room_width");
            this.If_room_width.Name = "If_room_width";
            // 
            // If_room_lenght
            // 
            this.If_room_lenght.DecimalPlaces = 1;
            this.If_room_lenght.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_room_lenght, "If_room_lenght");
            this.If_room_lenght.Name = "If_room_lenght";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel5);
            resources.ApplyResources(this.tabPage4, "tabPage4");
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label20);
            this.panel5.Controls.Add(this.textBox3);
            this.panel5.Controls.Add(this.btnCallWebservicePosition);
            this.panel5.Controls.Add(this.textBox2);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.textBox1);
            this.panel5.Controls.Add(this.label3);
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // textBox3
            // 
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.Name = "textBox3";
            // 
            // btnCallWebservicePosition
            // 
            resources.ApplyResources(this.btnCallWebservicePosition, "btnCallWebservicePosition");
            this.btnCallWebservicePosition.Name = "btnCallWebservicePosition";
            this.btnCallWebservicePosition.UseVisualStyleBackColor = true;
            this.btnCallWebservicePosition.Click += new System.EventHandler(this.btnCallWebservicePosition_Click);
            // 
            // textBox2
            // 
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.Name = "textBox2";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // btnHold
            // 
            resources.ApplyResources(this.btnHold, "btnHold");
            this.btnHold.Name = "btnHold";
            this.btnHold.UseVisualStyleBackColor = true;
            this.btnHold.Click += new System.EventHandler(this.btnHold_Click);
            // 
            // btnAbort
            // 
            resources.ApplyResources(this.btnAbort, "btnAbort");
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.UseVisualStyleBackColor = true;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnStop
            // 
            resources.ApplyResources(this.btnStop, "btnStop");
            this.btnStop.Name = "btnStop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnExecute
            // 
            resources.ApplyResources(this.btnExecute, "btnExecute");
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.UseVisualStyleBackColor = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Name = "label5";
            // 
            // HeaderPanel
            // 
            this.HeaderPanel.BackColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.HeaderPanel, "HeaderPanel");
            this.HeaderPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HeaderPanel.Controls.Add(this.pictureBox1);
            this.HeaderPanel.Controls.Add(this.label5);
            this.HeaderPanel.Controls.Add(this.label4);
            this.HeaderPanel.Name = "HeaderPanel";
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Image = global::Ground_station_GUI.Properties.Resources.WMI2drone_project;
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // btnClearMeasurment
            // 
            resources.ApplyResources(this.btnClearMeasurment, "btnClearMeasurment");
            this.btnClearMeasurment.Name = "btnClearMeasurment";
            this.btnClearMeasurment.UseVisualStyleBackColor = true;
            this.btnClearMeasurment.Click += new System.EventHandler(this.btnClearMeasurment_Click);
            // 
            // btnEditMeasurment
            // 
            resources.ApplyResources(this.btnEditMeasurment, "btnEditMeasurment");
            this.btnEditMeasurment.Name = "btnEditMeasurment";
            this.btnEditMeasurment.UseVisualStyleBackColor = true;
            this.btnEditMeasurment.Click += new System.EventHandler(this.btnEditMeasurment_Click);
            // 
            // btnAddMeasurment
            // 
            resources.ApplyResources(this.btnAddMeasurment, "btnAddMeasurment");
            this.btnAddMeasurment.Name = "btnAddMeasurment";
            this.btnAddMeasurment.UseVisualStyleBackColor = true;
            this.btnAddMeasurment.Click += new System.EventHandler(this.btnAddMeasurment_Click);
            // 
            // btnClearFlightTable
            // 
            resources.ApplyResources(this.btnClearFlightTable, "btnClearFlightTable");
            this.btnClearFlightTable.Name = "btnClearFlightTable";
            this.btnClearFlightTable.UseVisualStyleBackColor = true;
            this.btnClearFlightTable.Click += new System.EventHandler(this.btnClearFlightTable_Click);
            // 
            // btnGenerateFlightTable
            // 
            resources.ApplyResources(this.btnGenerateFlightTable, "btnGenerateFlightTable");
            this.btnGenerateFlightTable.Name = "btnGenerateFlightTable";
            this.btnGenerateFlightTable.UseVisualStyleBackColor = true;
            this.btnGenerateFlightTable.Click += new System.EventHandler(this.btnGenerateFlightTable_Click);
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Controls.Add(this.radioButton2);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // radioButton1
            // 
            resources.ApplyResources(this.radioButton1, "radioButton1");
            this.radioButton1.Checked = true;
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            resources.ApplyResources(this.radioButton2, "radioButton2");
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkGray;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.btnGenerateFlightTable);
            this.panel1.Controls.Add(this.btnClearFlightTable);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.If_Xposition);
            this.panel2.Controls.Add(this.If_Yposition);
            this.panel2.Controls.Add(this.If_Zposition);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.btnEditMeasurment);
            this.panel2.Controls.Add(this.btnClearMeasurment);
            this.panel2.Controls.Add(this.btnAddMeasurment);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.label28);
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // If_Xposition
            // 
            this.If_Xposition.DecimalPlaces = 1;
            this.If_Xposition.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_Xposition, "If_Xposition");
            this.If_Xposition.Name = "If_Xposition";
            // 
            // If_Yposition
            // 
            this.If_Yposition.DecimalPlaces = 1;
            this.If_Yposition.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_Yposition, "If_Yposition");
            this.If_Yposition.Name = "If_Yposition";
            // 
            // If_Zposition
            // 
            this.If_Zposition.DecimalPlaces = 1;
            this.If_Zposition.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.If_Zposition, "If_Zposition");
            this.If_Zposition.Name = "If_Zposition";
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.Name = "label30";
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.Name = "label29";
            // 
            // label28
            // 
            resources.ApplyResources(this.label28, "label28");
            this.label28.Name = "label28";
            // 
            // ControlPanel
            // 
            resources.ApplyResources(this.ControlPanel, "ControlPanel");
            this.ControlPanel.BackColor = System.Drawing.Color.DarkGray;
            this.ControlPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ControlPanel.Controls.Add(this.btnReset);
            this.ControlPanel.Controls.Add(this.label16);
            this.ControlPanel.Controls.Add(this.btnHold);
            this.ControlPanel.Controls.Add(this.btnExecute);
            this.ControlPanel.Controls.Add(this.btnStop);
            this.ControlPanel.Controls.Add(this.btnAbort);
            this.ControlPanel.Name = "ControlPanel";
            // 
            // btnReset
            // 
            resources.ApplyResources(this.btnReset, "btnReset");
            this.btnReset.Name = "btnReset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // BottomPanel
            // 
            this.BottomPanel.Controls.Add(this.panel1);
            this.BottomPanel.Controls.Add(this.panel3);
            this.BottomPanel.Controls.Add(this.panel2);
            resources.ApplyResources(this.BottomPanel, "BottomPanel");
            this.BottomPanel.Name = "BottomPanel";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.textBox6);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label7);
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // textBox4
            // 
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            // 
            // textBox5
            // 
            resources.ApplyResources(this.textBox5, "textBox5");
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            // 
            // textBox6
            // 
            resources.ApplyResources(this.textBox6, "textBox6");
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // Indication_timer
            // 
            this.Indication_timer.Enabled = true;
            this.Indication_timer.Interval = 500;
            this.Indication_timer.Tick += new System.EventHandler(this.Indication_timer_Tick);
            // 
            // GroundstationGUI
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.TabMenuStructure);
            this.Controls.Add(this.BottomPanel);
            this.Controls.Add(this.ControlPanel);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.HeaderPanel);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "GroundstationGUI";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.TopMost = true;
            this.Load += new System.EventHandler(this.GroundstationGUI_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.TabMenuStructure.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ModeSelectionPanel.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.mapViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tableViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tblNavigationPoints)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Xmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Zmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Zmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Ymax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Ymin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_safety_Xmin)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.If_drone_intial_Zposition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_drone_intial_Yposition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_drone_intial_Xposition)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.If_room_height)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_room_width)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_room_lenght)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.HeaderPanel.ResumeLayout(false);
            this.HeaderPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.If_Xposition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_Yposition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.If_Zposition)).EndInit();
            this.ControlPanel.ResumeLayout(false);
            this.ControlPanel.PerformLayout();
            this.BottomPanel.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Timer dronePositionUpdate;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.TabControl TabMenuStructure;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button btnCallWebservicePosition;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnHold;
        private System.Windows.Forms.Button btnAbort;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnSubmitAdjustRoom;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnSubmitDroneInitialPosition;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel HeaderPanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel ControlPanel;
        protected System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel ModeSelectionPanel;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnClearMeasurment;
        private System.Windows.Forms.Button btnEditMeasurment;
        private System.Windows.Forms.Button btnAddMeasurment;
        private System.Windows.Forms.Button btnClearFlightTable;
        private System.Windows.Forms.Button btnGenerateFlightTable;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel BottomPanel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel tableViewPanel;
        private System.Windows.Forms.DataGridView tblNavigationPoints;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Panel mapViewPanel;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Timer Indication_timer;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.NumericUpDown If_Zposition;
        private System.Windows.Forms.NumericUpDown If_Xposition;
        private System.Windows.Forms.NumericUpDown If_Yposition;
        private System.Windows.Forms.NumericUpDown If_drone_intial_Zposition;
        private System.Windows.Forms.NumericUpDown If_drone_intial_Yposition;
        private System.Windows.Forms.NumericUpDown If_drone_intial_Xposition;
        private System.Windows.Forms.NumericUpDown If_room_height;
        private System.Windows.Forms.NumericUpDown If_room_width;
        private System.Windows.Forms.NumericUpDown If_room_lenght;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.NumericUpDown If_safety_Xmax;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown If_safety_Zmax;
        private System.Windows.Forms.NumericUpDown If_safety_Zmin;
        private System.Windows.Forms.NumericUpDown If_safety_Ymax;
        private System.Windows.Forms.NumericUpDown If_safety_Ymin;
        private System.Windows.Forms.NumericUpDown If_safety_Xmin;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnSubmitSafetyBox;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
    }
}

