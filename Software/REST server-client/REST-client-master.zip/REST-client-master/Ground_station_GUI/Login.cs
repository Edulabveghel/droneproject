﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ground_station_GUI
{
        public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string userName = "admin";
            string password = "admin";
            //string userName = "";
            //string password = "";

            if (textBox1.Text == userName && textBox2.Text == password)
            {
                GroundstationGUI Main_page = new GroundstationGUI();
                this.Hide();
                Main_page.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Wrong username or password");
            }
        }
    }
}
