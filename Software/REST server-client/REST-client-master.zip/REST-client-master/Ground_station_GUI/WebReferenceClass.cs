﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ground_station_GUI
{
    public class Position
    {
        public float Xpos;
        public float Ypos;
        public float Zpos;
    }
    public class State
    {
        public string sytemState;
    }
    public class Sensor
    {
        //ultrasonic sensor data [mm] (-1 means invallid)
        public class Ultrasonic_distance
        {
            public short front;
            public short right;
            public short rear;
            public short left;
            public short down;
        }

        //velocity sensor data[mm/s]
        public class Velocity
        {
            public short front;
            public short right;
            public short rear;
            public short left;
            public short down;
        }

        //obstacle distance [cm]
        public class Obstacle_distance
        {
            public ushort front;
            public ushort right;
            public ushort rear;
            public ushort left;
            public ushort down;
        }

        //IMU acceleration [m/s^2]
        public class IMU_ACC
        {
            public float acc_X;
            public float acc_Y;
            public float acc_Z;
        }
    }
    public class Command
    {
        public string systenCommand;
    }

    public class PathEntry
    {
        public int Index { get; set; }
        public double Xpos { get; set; }
        public double Ypos { get; set; }
        public double Zpos { get; set; }
        public int MeasurementType { get; set; } //navigation vs measurment
    }
}
