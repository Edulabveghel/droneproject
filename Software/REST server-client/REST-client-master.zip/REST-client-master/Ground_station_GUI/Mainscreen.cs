﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Windows.Forms.DataVisualization.Charting;
using System.Collections;
using System.Net.Http;

namespace Ground_station_GUI
{

    public partial class GroundstationGUI : Form
    {
        double roomWidth = 19.0;
        double roomLenght = 22.0;
        double roomHeight = 3.0;
        Position get_position = new Position();
        bool menuSelection = false;
        double X_click_position;
        double Y_click_position;
        List<PathEntry> navigationPointsList = new List<PathEntry>();
        bool holdCursor = false;
        private Rectangle safetyZone;
        WebReference.Service Webservice = new WebReference.Service();
        public GroundstationGUI()
        {
            InitializeComponent();
        }
        async void GetRequest(string url)
        {
            using (HttpClient client = new HttpClient())
            {
                using (HttpResponseMessage response = await client.GetAsync(url))
                {
                    using (HttpContent content = response.Content)
                    {
                        string httpResponse = await content.ReadAsStringAsync();
                        JavaScriptSerializer ser = new JavaScriptSerializer();
                        
                        //call webservice and fill in data
                        get_position = JsonConvert.DeserializeObject<Position>(httpResponse);

                        //show only the recent position
                        chart1.Series["Drone position"].Points.Clear();
                        chart1.Series["Drone position"].Points.AddXY(get_position.Xpos, get_position.Ypos);
                        chart2.Series["Drone position"].Points.Clear();
                        chart2.Series["Drone position"].Points.AddXY(get_position.Xpos, get_position.Ypos);
                    }
                }
            }
        }

        private void DronePositionIdication(string state_command)
        {
            switch (state_command)
            {
                case "State: idle":
                    if (chart1.Series["Drone position"].Color == Color.LightGreen)
                    {
                        chart1.Series["Drone position"].Color = Color.Transparent;
                    }
                    else
                    {
                        chart1.Series["Drone position"].Color = Color.LightGreen;
                    }
                    break;
                case "State: execute":
                    chart1.Series["Drone position"].Color = Color.Green;
                    break;
                case "State: held":
                    chart1.Series["Drone position"].Color = Color.Orange;
                    break;
                case "State: stoped":
                    chart1.Series["Drone position"].Color = Color.Red;
                    break;
                case "State: aborted":
                    if (chart1.Series["Drone position"].Color == Color.Red)
                    {
                        chart1.Series["Drone position"].Color = Color.Transparent;
                    }
                    else
                    {
                        chart1.Series["Drone position"].Color = Color.Red;
                    }
                    break;
                case "State: reset":
                    chart1.Series["Drone position"].Color = Color.Blue;
                    toolStripStatusLabel1.Text = "State: idle";
                    break;
            }

            //shadow color to other chart
            chart2.Series["Drone position"].Color = chart1.Series["Drone position"].Color;
        }
        private Position GetPositionFromWebservice()
        {
            Position return_object = new Position();
            JavaScriptSerializer ser = new JavaScriptSerializer();
            string jsonData = "";

            //call webservice and fill in data
            jsonData = Webservice.GetPosition();
            return_object = JsonConvert.DeserializeObject<Position>(jsonData);

            return return_object;
        }
        private void GroundstationGUI_Load(object sender, EventArgs e)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            string jsonData = "";

            //show state in status strip
            toolStripStatusLabel1.Text = "State: idle";

            //init point graph and add actual drone position
            chart1.Series.Clear();
            chart1.Series.Add("Drone position");
            chart1.Series["Drone position"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            chart1.Series["Drone position"].MarkerSize = 15;
            chart1.Series["Drone position"].MarkerStyle = MarkerStyle.Cross;
            chart1.Series["Drone position"].Color = Color.Red;
            chart1.Series["Drone position"].IsVisibleInLegend = true;
            chart1.ChartAreas[0].AxisX.Title = "X axis";
            chart1.ChartAreas[0].AxisY.Title = "Y axis";
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = roomLenght;
            chart1.ChartAreas[0].AxisY.Minimum = 0;
            chart1.ChartAreas[0].AxisY.Maximum = roomWidth;
            chart2.Series.Clear();
            chart2.Series.Add("Drone position");
            chart2.Series["Drone position"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            chart2.Series["Drone position"].MarkerSize = 15;
            chart2.Series["Drone position"].MarkerStyle = MarkerStyle.Cross;
            chart2.Series["Drone position"].Color = Color.Red;
            chart2.Series["Drone position"].IsVisibleInLegend = true;
            chart2.ChartAreas[0].AxisX.Title = "X axis";
            chart2.ChartAreas[0].AxisY.Title = "Y axis";
            chart2.ChartAreas[0].AxisX.Minimum = 0;
            chart2.ChartAreas[0].AxisX.Maximum = roomLenght;
            chart2.ChartAreas[0].AxisY.Minimum = 0;
            chart2.ChartAreas[0].AxisY.Maximum = roomWidth;
            //chart1.Series["Drone position"].IsValueShownAsLabel = true;

            //second series form measurment points
            chart1.Series.Add("Measurment point");
            chart1.Series["Measurment point"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            chart1.Series["Measurment point"].MarkerSize = 8;
            chart1.Series["Measurment point"].MarkerStyle = MarkerStyle.Diamond;
            chart1.Series["Measurment point"].Color = Color.Blue;
            chart1.Series["Measurment point"].IsVisibleInLegend = true;
            chart2.Series.Add("Measurment point");
            chart2.Series["Measurment point"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            chart2.Series["Measurment point"].MarkerSize = 8;
            chart2.Series["Measurment point"].MarkerStyle = MarkerStyle.Diamond;
            chart2.Series["Measurment point"].Color = Color.Blue;
            chart2.Series["Measurment point"].IsVisibleInLegend = true;


            //call webservice and fill in data
            get_position = GetPositionFromWebservice();
            textBox1.Text = Convert.ToString(get_position.Xpos);
            textBox2.Text = Convert.ToString(get_position.Ypos);
            textBox3.Text = Convert.ToString(get_position.Zpos);
            chart1.Series["Drone position"].Points.AddXY(get_position.Xpos, get_position.Ypos);
            chart2.Series["Drone position"].Points.AddXY(get_position.Xpos, get_position.Ypos);

            //set inital room size
            If_room_lenght.Value = Convert.ToDecimal(roomLenght);
            If_room_width.Value = Convert.ToDecimal(roomWidth);
            If_room_height.Value = Convert.ToDecimal(roomHeight);

            //disable menu modeselection panel
            ModeSelectionPanel.Enabled = false;
            BottomPanel.Enabled = false;
            radioButton4.Checked = true;
            
            //set safety box limits
            If_safety_Xmin.Value = Convert.ToDecimal(0.5);
            If_safety_Xmax.Value = Convert.ToDecimal(21.5);
            If_safety_Ymin.Value = Convert.ToDecimal(4.5);
            If_safety_Ymax.Value = Convert.ToDecimal(11.0);
            If_safety_Zmin.Value = Convert.ToDecimal(0.0);
            If_safety_Zmax.Value = Convert.ToDecimal(3.0);

            //write safety limits to control elements
            If_Xposition.Maximum = Convert.ToDecimal(If_safety_Xmax.Value);
            If_Xposition.Minimum = Convert.ToDecimal(If_safety_Xmin.Value);
            If_Yposition.Maximum = Convert.ToDecimal(If_safety_Ymax.Value);
            If_Yposition.Minimum = Convert.ToDecimal(If_safety_Ymin.Value);
            If_Zposition.Maximum = Convert.ToDecimal(If_safety_Zmax.Value);
            If_Zposition.Minimum = Convert.ToDecimal(If_safety_Zmin.Value);
        }
        private void btnExecute_Click(object sender, EventArgs e)
        {
            //command execute
            toolStripStatusLabel1.Text = "State: execute";
            Webservice.SetCommand("execute");
        }
        private void btnHold_Click(object sender, EventArgs e)
        {
            //command hold
            toolStripStatusLabel1.Text = "State: held";
            Webservice.SetCommand("hold");
        }
        private void btnStop_Click(object sender, EventArgs e)
        {
            //command stop
            toolStripStatusLabel1.Text = "State: stoped";
            Webservice.SetCommand("stop");
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            //command reset
            toolStripStatusLabel1.Text = "State: reset";
            Webservice.SetCommand("reset");
        }
        private void btnAbort_Click(object sender, EventArgs e)
        {
            //command abort
            toolStripStatusLabel1.Text = "State: aborted";
            Webservice.SetCommand("abort");
        }
        private void btnAdjustRoom_Click(object sender, EventArgs e)
        {
            roomLenght = Convert.ToDouble(If_room_lenght.Value);
            roomWidth = Convert.ToDouble(If_room_width.Value);
            roomHeight = Convert.ToDouble(If_room_height.Value);
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = roomLenght;
            chart1.ChartAreas[0].AxisY.Minimum = 0;
            chart1.ChartAreas[0].AxisY.Maximum = roomWidth;
            chart2.ChartAreas[0].AxisX.Minimum = 0;
            chart2.ChartAreas[0].AxisX.Maximum = roomLenght;
            chart2.ChartAreas[0].AxisY.Minimum = 0;
            chart2.ChartAreas[0].AxisY.Maximum = roomWidth;
            MessageBox.Show("The room has been changed!");
        }
        private void chart1_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePoint = new Point(e.X, e.Y);

            //set the snapping interval off the cursor
            chart1.ChartAreas[0].CursorX.Interval = 0.5;
            chart1.ChartAreas[0].CursorY.Interval = 0.5;
            chart2.ChartAreas[0].CursorX.Interval = 0.5;
            chart2.ChartAreas[0].CursorY.Interval = 0.5;

            //plot a cursor cross
            chart1.ChartAreas[0].CursorX.SetCursorPixelPosition(mousePoint, true);
            chart1.ChartAreas[0].CursorY.SetCursorPixelPosition(mousePoint, true);

            //lock cursor if a measurment point is in edit mode
            if (holdCursor == false)
            {
                chart2.ChartAreas[0].CursorX.SetCursorPixelPosition(mousePoint, true);
                chart2.ChartAreas[0].CursorY.SetCursorPixelPosition(mousePoint, true);
            }

            HitTestResult result1 = chart1.HitTest(e.X, e.Y);
            HitTestResult result2 = chart2.HitTest(e.X, e.Y);

            if ((result1.PointIndex > -1 && result1.ChartArea != null) && TabMenuStructure.SelectedTab == tabPage1)
            {
                textBox5.Text = result1.Series.Points[result1.PointIndex].XValue.ToString();
                textBox4.Text = result1.Series.Points[result1.PointIndex].YValues[0].ToString();
            }
            else if ((result2.PointIndex > -1 && result2.ChartArea != null) && TabMenuStructure.SelectedTab == tabPage2)
            {
                textBox5.Text = result2.Series.Points[result2.PointIndex].XValue.ToString();
                textBox4.Text = result2.Series.Points[result2.PointIndex].YValues[0].ToString();
            }
        }
        private void TabMenuStructure_TabIndexChanged(object sender, EventArgs e)
        {
            switch (TabMenuStructure.SelectedIndex)
            {
                // View screen
                case 0:
                    ModeSelectionPanel.Enabled = false;
                    BottomPanel.Enabled = false;
                    panel1.Enabled = false;
                    panel3.Enabled = false;
                    panel3.Enabled = false;
                    break;

                // Flightplanner screen
                case 1:
                    ModeSelectionPanel.Enabled = true;
                    BottomPanel.Enabled = true;
                    panel1.Enabled = true;
                    panel2.Enabled = false;
                    panel3.Enabled = true;
                    break;

                // Settings screen
                case 2:
                    ModeSelectionPanel.Enabled = false;
                    BottomPanel.Enabled = false;
                    panel1.Enabled = false;
                    panel3.Enabled = false;
                    panel3.Enabled = false;
                    break;

                // Maintenance screen
                case 3:
                    ModeSelectionPanel.Enabled = false;
                    BottomPanel.Enabled = false;
                    panel1.Enabled = false;
                    panel3.Enabled = false;
                    panel3.Enabled = false;
                    break;
            }

        }
        private void btnAddMeasurment_Click(object sender, EventArgs e)
        {
            double z_position = Convert.ToDouble(If_Zposition.Value);
            int type = Convert.ToInt16(radioButton1.Checked);

            //add measurment id and gather information about measurment
            int rowIndex = navigationPointsList.Count;
            navigationPointsList.Add(new PathEntry() { Index = rowIndex, Xpos = X_click_position, Ypos = Y_click_position, Zpos = z_position, MeasurementType = type });

            //add the point to the chart
            chart1.Series["Measurment point"].Points.AddXY(X_click_position, Y_click_position);
            chart2.Series["Measurment point"].Points.AddXY(X_click_position, Y_click_position);

            //rebind the datesource with the table to update data
            tblNavigationPoints.DataSource = null;
            tblNavigationPoints.DataSource = navigationPointsList;

            //release the cursor
            holdCursor = false;
            panel2.Enabled = false;
        }
        private void btnClearMeasurment_Click(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                //get the selected row index and delete row
                int currentRow = tblNavigationPoints.CurrentRow.Index;
                navigationPointsList.RemoveAt(currentRow);

                //remove the point in both charts
                chart1.Series["Measurment point"].Points.RemoveAt(currentRow);
                chart2.Series["Measurment point"].Points.RemoveAt(currentRow);

                //rebind the datesource with the table to update data
                tblNavigationPoints.DataSource = null;
                tblNavigationPoints.DataSource = navigationPointsList;
            }
            //set user controls to intital position
            radioButton1.Checked = true;
            If_Xposition.Value = Convert.ToDecimal(If_safety_Xmin.Value);
            If_Yposition.Value = Convert.ToDecimal(If_safety_Ymin.Value);
            If_Zposition.Value = Convert.ToDecimal(If_safety_Zmin.Value); 
            
            //release the cursor
            holdCursor = false;
            panel2.Enabled = false;
        }
        private void btnEditMeasurment_Click(object sender, EventArgs e)
        {
            //release the cursor
            holdCursor = false;
            panel2.Enabled = false;
            int currentRow = tblNavigationPoints.CurrentRow.Index;
            
            //Write cycle to table/ list
            tblNavigationPoints.SelectedRows[0].Cells[1].Value = Convert.ToDecimal(If_Xposition.Value);
            tblNavigationPoints.SelectedRows[0].Cells[2].Value = Convert.ToDecimal(If_Yposition.Value);
            tblNavigationPoints.SelectedRows[0].Cells[3].Value = Convert.ToDecimal(If_Zposition.Value);
            tblNavigationPoints.SelectedRows[0].Cells[4].Value = Convert.ToInt16(radioButton1.Checked);

            //remove old point from chart and enter a replacement point
            chart1.Series["Measurment point"].Points.RemoveAt(currentRow);
            chart2.Series["Measurment point"].Points.RemoveAt(currentRow);
            chart1.Series["Measurment point"].Points.InsertXY(currentRow, Convert.ToDecimal(If_Xposition.Value), Convert.ToDecimal(If_Yposition.Value));
            chart2.Series["Measurment point"].Points.InsertXY(currentRow, Convert.ToDecimal(If_Xposition.Value), Convert.ToDecimal(If_Yposition.Value));
            chart1.Update();
            chart2.Update();
        }
        private void btnClearFlightTable_Click(object sender, EventArgs e)
        {
            navigationPointsList.Clear();

            //rebind the datesource with the table to update data
            tblNavigationPoints.DataSource = null;
            tblNavigationPoints.DataSource = navigationPointsList;

            //set user controls to intital position
            radioButton1.Checked = true;
            If_Xposition.Value = Convert.ToDecimal(If_safety_Xmin.Value);
            If_Yposition.Value = Convert.ToDecimal(If_safety_Ymin.Value);
            If_Zposition.Value = Convert.ToDecimal(If_safety_Zmin.Value);

            //clear all measurment points from chart
            chart1.Series["Measurment point"].Points.Clear();
            chart2.Series["Measurment point"].Points.Clear();
        }
        private void dronePositionUpdate_Tick(object sender, EventArgs e)
        {
            //call webservice to get last drone position
            GetRequest("http://10.240.221.200/api/position");
        }
        private void tblNavigationPoints_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            //re_index the gridview after removal of rows
            this.tblNavigationPoints.Rows[e.RowIndex].Cells[0].Value = (e.RowIndex + 1).ToString();
        }
        private void tblNavigationPoints_SelectionChanged(object sender, EventArgs e)
        {
            int currentRow = tblNavigationPoints.CurrentRow.Index;

            panel1.Enabled = true;
            panel2.Enabled = true;
            panel3.Enabled = true;

            //enable screen when cell is selected
            if (tblNavigationPoints.SelectedRows.Count > 0)
            {
                If_Xposition.Value = Convert.ToDecimal(tblNavigationPoints.SelectedRows[0].Cells[1].Value + string.Empty);
                If_Yposition.Value = Convert.ToDecimal(tblNavigationPoints.SelectedRows[0].Cells[2].Value + string.Empty);
                If_Zposition.Value = Convert.ToDecimal(tblNavigationPoints.SelectedRows[0].Cells[3].Value + string.Empty);
                radioButton1.Checked = Convert.ToBoolean(tblNavigationPoints.SelectedRows[0].Cells[4].Value);
            }

            //mirror inversed to second radio button
            radioButton2.Checked = !radioButton1.Checked;

            //refresh the input fields to show new data
            If_Xposition.Refresh();
            If_Yposition.Refresh();
            If_Zposition.Refresh();
        }
        private void btnGenerateFlightTable_Click(object sender, EventArgs e)
        {
            //check if the navigation point list contaims any  elements
            if (navigationPointsList.Count > 0)
            {
                MessageBox.Show("Generating and transmitting flight table ...");
            }
        }
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            //function to handle table/ map menu
            if (radioButton4.Checked == true)
            {
                mapViewPanel.Visible = true;
                mapViewPanel.Enabled = true;
                tableViewPanel.Visible = false;
                tableViewPanel.Enabled = false;
                btnEditMeasurment.Enabled = false;
                btnAddMeasurment.Enabled = true;
            }
            else
            {
                mapViewPanel.Visible = false;
                mapViewPanel.Enabled = false;
                tableViewPanel.Visible = true;
                tableViewPanel.Enabled = true;
                btnEditMeasurment.Enabled = true;
                btnAddMeasurment.Enabled = false;
            }
        }
        private void Indication_timer_Tick(object sender, EventArgs e)
        {
            //make the drone position color indication state depending
            DronePositionIdication(toolStripStatusLabel1.Text);
        }

        private void chart2_MouseClick(object sender, MouseEventArgs e)
        {
            //get mouse position
            double x = chart2.ChartAreas[0].AxisX.PixelPositionToValue(e.X);
            double y = chart2.ChartAreas[0].AxisY.PixelPositionToValue(e.Y);
            double xmin = Convert.ToDouble(If_safety_Xmin.Value);
            double xmax = Convert.ToDouble(If_safety_Xmax.Value);
            double ymin = Convert.ToDouble(If_safety_Ymin.Value);
            double ymax = Convert.ToDouble(If_safety_Ymax.Value);

            //round to 0.5
            X_click_position = Math.Round(x * 2) / 2;
            Y_click_position = Math.Round(y * 2) / 2;

            //disable the edit button in map mode
            btnEditMeasurment.Enabled = false;

            //check if the cursor is whitin range
            if ((X_click_position > xmin && X_click_position < xmax) && (Y_click_position > ymin && Y_click_position < ymax)) 
            {
                If_Xposition.Value = Convert.ToDecimal(X_click_position);
                If_Yposition.Value = Convert.ToDecimal(Y_click_position);

                //lock cursor until complete
                holdCursor = true;
                panel2.Enabled = true;
            }
            else
            {
                //release cursor and try again
                holdCursor = false;
                panel2.Enabled = false;
            }
        }

        private void btnSubmitSafetyBox_Click(object sender, EventArgs e)
        {
            //write safety limits to control elements
            If_Xposition.Maximum = Convert.ToDecimal(If_safety_Xmax.Value);
            If_Xposition.Minimum = Convert.ToDecimal(If_safety_Xmin.Value);
            If_Yposition.Maximum = Convert.ToDecimal(If_safety_Ymax.Value);
            If_Yposition.Minimum = Convert.ToDecimal(If_safety_Ymin.Value);
            If_Zposition.Maximum = Convert.ToDecimal(If_safety_Zmax.Value);
            If_Zposition.Minimum = Convert.ToDecimal(If_safety_Zmin.Value);

            //throw a message to inform the user
            MessageBox.Show("The safety zone has been changed!");
        }

        private void btnSubmitDroneInitialPosition_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The inital position off the drone has been changed!");
        }

        private void btnCallWebservicePosition_Click(object sender, EventArgs e)
        {
            //call webservice to get last drone position
            GetRequest("http://10.240.221.200/api/position");

            textBox1.Text = Convert.ToString(get_position.Xpos);
            textBox2.Text = Convert.ToString(get_position.Ypos);
            textBox3.Text = Convert.ToString(get_position.Zpos);
            chart1.Series["Drone position"].Points.Clear();
            chart1.Series["Drone position"].Points.AddXY(get_position.Xpos, get_position.Ypos);
            chart2.Series["Drone position"].Points.Clear();
            chart2.Series["Drone position"].Points.AddXY(get_position.Xpos, get_position.Ypos);
        }

        private void chart2_PostPaint(object sender, ChartPaintEventArgs e)
        {
            //set sizing of the safety rectangle
            safetyZone.X = Convert.ToInt16(chart2.ChartAreas[0].AxisX.ValueToPixelPosition(Convert.ToDouble(If_safety_Xmin.Value)));
            int xFar = Convert.ToInt16(chart2.ChartAreas[0].AxisX.ValueToPixelPosition(Convert.ToDouble(If_safety_Xmax.Value)));
            safetyZone.Y = Convert.ToInt16(chart2.ChartAreas[0].AxisY.ValueToPixelPosition(Convert.ToDouble(If_safety_Ymax.Value)));
            int YFar = Convert.ToInt16(chart2.ChartAreas[0].AxisY.ValueToPixelPosition(Convert.ToDouble(If_safety_Ymin.Value)));

            safetyZone.Width = xFar - safetyZone.X;
            safetyZone.Height = YFar - safetyZone.Y;

            //draw the safety rectangle
            e.ChartGraphics.Graphics.DrawRectangle(new Pen(Color.Firebrick, 2), safetyZone);
        }
    }
}