﻿using System;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using Newtonsoft.Json;

public class Position
{
    public float Xpos;
    public float Ypos;
    public float Zpos;
}
public class State
{
    public string sytemState;
}
public class Sensor
{
    //ultrasonic sensor data [mm] (-1 means invallid)
  public class Ultrasonic_distance
     {
        public short front;
        public short right;
        public short rear;
        public short left;
        public short down;
    }

    //velocity sensor data[mm/s]
    public class Velocity
    {
        public short front;
        public short right;
        public short rear;
        public short left;
        public short down;
    }

    //obstacle distance [cm]
    public class Obstacle_distance
    {
        public ushort front;
        public ushort right;
        public ushort rear;
        public ushort left;
        public ushort down;
    }

    //IMU acceleration [m/s^2]
    public class IMU_ACC
    {
        public float acc_X;
        public float acc_Y;
        public float acc_Z;
    }
}
public class Command
{
    public string systenCommand;
}

public class PathEntry
{
    public int Xpos;
    public int Ypos;
    public int Zpos;
    public int type; //navigation vs measurment
}

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    public Service()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string GetPosition()
    {
        //generate objects
        Position PositionStatus = new Position();
        Random random = new Random();

        //fill the object with data
        PositionStatus.Xpos = random.Next(1, 13);
        PositionStatus.Ypos = random.Next(1, 6);
        PositionStatus.Zpos = random.Next(1, 25);

        //initialise a JSON object and assemble JSON string
        string json_response = "";
        JavaScriptSerializer jss = new JavaScriptSerializer();
        json_response = jss.Serialize(PositionStatus);

        //return object in JSON formating
        return json_response;
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string GetStatus()
    {
        //generate objects
        State stateInfo = new State();
        //fill the object with data
        stateInfo.sytemState = "Idle";

        //initialise a JSON object and assemble JSON string
        string json_response = "";
        JavaScriptSerializer jss = new JavaScriptSerializer();
        json_response = jss.Serialize(stateInfo);

        //return object in JSON formating
        return json_response;
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string GetSensorInfo()
    {
        //generate objects
        Sensor sensorState = new Sensor();
        Sensor.Ultrasonic_distance ultrasonic = new Sensor.Ultrasonic_distance();
        Sensor.Velocity velocity = new Sensor.Velocity();
        Sensor.Obstacle_distance obstackle_distance = new Sensor.Obstacle_distance();
        Sensor.IMU_ACC IMU_acc = new Sensor.IMU_ACC();

        //fill the object with data
        
        //initialise a JSON object and assemble JSON string
        string json_response = "";
        JavaScriptSerializer jss = new JavaScriptSerializer();
        json_response = jss.Serialize(ultrasonic);

        //return object in JSON formating
        return json_response;
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public bool SetCommand(string command)
    {
        //generate objects
        Command clientCommand = new Command();
        clientCommand.systenCommand = command;

        //return object in JSON formating
        return true;
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string SetPathTable(int numberOffIndexes, string JsonFormatTable)
    {
        //generate objects
        PathEntry[] pathtable  = new PathEntry[numberOffIndexes];
        
        JavaScriptSerializer ser = new JavaScriptSerializer();
    for(int index = 0; index < numberOffIndexes; index++)
        {
            pathtable[index] = JsonConvert.DeserializeObject<PathEntry>(JsonFormatTable);
        }

        //return Acknowledge bit
        return JsonFormatTable;
    }
}