#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <malloc.h>
#include <string.h>
#include <sys/socket.h>
#include <resolv.h>
#include <netdb.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

class Client {
public:
    void init(const char* hostname, int portNum);
    void sendMessage(char * message);
private:
    
    int _nPortNum = 443;
    const char *_cHostName;
    
    
    void ShowCerts(SSL* ssl);
    SSL_CTX* initCTX(void);
    int OpenConnection(const char *hostname, int port);
protected:
};

