
#include <stdio.h>
#include "Client.h"
int main(int count, char *strings[]){
    Client client;
    client.init("127.0.0.1" , 443);
    client.sendMessage("multiple ");
    client.sendMessage("message");
    client.sendMessage("test");

    return 0;
}
