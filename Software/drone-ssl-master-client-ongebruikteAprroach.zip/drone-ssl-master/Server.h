#include <errno.h>
#include <unistd.h>
#include <malloc.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <resolv.h>
#include "openssl/ssl.h"
#include "openssl/err.h"
#include <stdio.h>

class Server {
public:
    void test(int count, char* strings[]);

private:
    int OpenListener(int port);
    int isRoot();
    SSL_CTX* InitServerCTX(void) ;
    void loadCertificates(SSL_CTX* ctx, char* CertFile, char* KeyFile) ;
    void ShowCerts(SSL* ssl);
    void Servlet(SSL *);
protected:
};

