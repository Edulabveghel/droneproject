# drone-ssl
Compiler: gcc Main.cpp Server.cpp -o server -L/usr/lib -lssl -lcrypto


https://www.cs.utah.edu/~swalton/listings/articles/ssl_server.c
https://www.cs.utah.edu/~swalton/listings/articles/ssl_client.c
