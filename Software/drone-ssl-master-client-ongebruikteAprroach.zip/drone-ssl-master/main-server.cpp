#include <stdio.h>
#include "Server.h"


int main(int count, char *strings[]) {
    Server serv;
    serv.test(count, strings);
    return 0;
}
