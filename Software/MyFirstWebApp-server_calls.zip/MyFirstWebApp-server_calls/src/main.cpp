#include <QCoreApplication>
#include <QSettings>

#include "httplistener.h"
#include "httprequesthandler.h"

#include "servercontroller.h"

using namespace stefanfrings;

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    QSettings* listenerSettings = new QSettings("../MyFirstWebApp/etc/webapp1.ini",QSettings::IniFormat,&app);
    listenerSettings->beginGroup("listener");

    // Start the HTTP server
    new HttpListener(listenerSettings, new ServerController(&app), &app);

    return app.exec();
}

