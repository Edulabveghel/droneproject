#include "servercontroller.h"

#include <QMultiMap>

ServerController::ServerController(QObject* parent)
    : HttpRequestHandler(parent) {
    // empty
}

ServerController::~ServerController() {
    // empty
}

void ServerController::service(HttpRequest &request, HttpResponse &response) {
    QString path = request.getPath();
    if (path == "/api/position") {
        if (request.getMethod() == "GET") {
           getPosition(response);
        } else if (request.getMethod() == "PUT") {
            // extract data
            setPosition(request, response);
        }
    } else if(path =="/api/setpath") {
        setPath(request,response);
    } else {
        response.setStatus(404);
        response.setHeader("Content-Type", "text/html");
        response.write("Page not found");
    }
}

void ServerController::getPosition(HttpResponse &response) {
    qsrand(0);
    int xpos = rand() % 19 + 0;
    int ypos = rand() % 12 + 0;
    int zpos = rand() % 4 + 0;
    response.setStatus(200);
    response.setHeader("Content-Type", "application/json");

    QString responseJSON = ("{\"position\":{\"Xaxis\":");
    responseJSON.append(QString::number(xpos));
    responseJSON.append(",\"Yaxis\":");
    responseJSON.append(QString::number(ypos));
    responseJSON.append(",\"Zaxis\":");
    responseJSON.append(QString::number(zpos));
    responseJSON.append("}}");
    response.write(responseJSON.toUtf8());
}

void ServerController::setPosition(HttpRequest &request, HttpResponse &response) {
    QString body = request.getBody();
    response.write(body.toUtf8() + "test");
    xCoor = 0;
    yCoor = 0;
    zCoor = 0;
}

void ServerController::setPath(HttpRequest &request, HttpResponse &response) {
    QMultiMap <QByteArray,QByteArray> headerList= request.getHeaderMap();
    QList<QByteArray> list = headerList.values("coor");
    QString body = request.getHeader("coor1");
    qDebug() << ("Set new path");
    for (int i = 0; i < list.size(); i++) {
        qDebug() << (list.at(i));
    }
}
