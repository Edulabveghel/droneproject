#ifndef SERVERCONTROLLER_H
#define SERVERCONTROLLER_H

#include "httprequesthandler.h"

using namespace stefanfrings;

class ServerController : public HttpRequestHandler {
    Q_OBJECT
public:
    ServerController(QObject* parent=0);
    virtual ~ServerController();
    virtual void service(HttpRequest& request, HttpResponse& response);
private:
    virtual void getPosition(HttpResponse& response);
    virtual void setPosition(HttpRequest &request, HttpResponse &response);
    virtual void setPath(HttpRequest &request, HttpResponse &response);
private:
    int xCoor;
    int yCoor;
    int zCoor;
};

#endif // SERVERCONTROLLER_H
